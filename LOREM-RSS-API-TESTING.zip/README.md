# Lorem RSS Feed - Python Test Harness
## Prerequisites
* Python3
* PIP3
### Follow below instructions to run
* CD to LOREM-RSS-API-TESTING using CMD
* pip install -r requirements.txt
* run command ```pytest -v test-case --html=LOREM-RSS-API-TESTING_report.html --self-contained-html``` to execute the tests.
* Verify the LOREM-RSS-API-TESTING_report.html to view the test results.